/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#ifndef __IOTX_OTA_CONFIG_H__
#define __IOTX_OTA_CONFIG_H__

#ifndef OTA_SIGNAL_CHANNEL
    #define OTA_SIGNAL_CHANNEL      (1)
#endif

#endif  /* __IOTX_OTA_CONFIG_H__ */
