/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */




#ifndef _IOTX_SHADOW_H_
#define _IOTX_SHADOW_H_
#if defined(__cplusplus)
extern "C" {
#endif

#include "iot_import.h"
#include "iot_export.h"


#endif /* _IOTX_SHADOW_H_ */
