/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#ifndef __DEV_DIAGNOSIS_H__
#define __DEV_DIAGNOSIS_H__

#if defined(__cplusplus)
extern "C" {
#endif

#include "iot_export.h"

#if defined(__cplusplus)
}       /* extern "C" */
#endif
#endif  /* __DEV_DIAGNOSIS_H__ */